﻿
using BooksApp.Helpers;
using BooksApp.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BooksApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class BooksController : ControllerBase
    {
        private readonly DatabaseContext database;

        public BooksController(DatabaseContext database)
        {
            this.database = database;
        }

        //GET /api/books
        [HttpGet]
        public IActionResult GetAll()
        {
            var books = database.Books.Include(b => b.Author).ToList();

            return Ok(books) ;
        }

        //GET /api/books/{id:int}
        [HttpGet("{id:int}")]
        public IActionResult GetById(int id)
        {
          var book = database.Books.Include(b => b.Author).FirstOrDefault(b => b.Id == id);
           //var book = database.Books.Find(id);
            if (book == null)
                return NotFound();
   
            return Ok(book);
        }

        //GET /api/books/by-author/{id}
        [HttpGet("by-author/{authorId:int}")]
        public IActionResult GetByAuthor(int authorId)
        {
            var author = database.Authors.FirstOrDefault(a => a.Id == authorId);
            if (author == null)
                return NotFound();

            var books=database.Books.Where(b => b.Author==author);
            return Ok(books);

        }


        //GET /api/books/{title}
        [HttpGet("{title}")]
        public IActionResult GetByTitle(string title)
        {
            var books = database.Books.Where(b => b.Title.StartsWith(title));
          
            if (books == null)
                return NotFound();

            return Ok(books.ToList());
        }


        //POST api/books
        [HttpPost]
        public  IActionResult Add(Book book)
        {
            database.Books.Add(book);
            database.SaveChanges();

            return Ok(book);
        }



        //PUT api/books/{id}
        [HttpPut("{id}")]
        public IActionResult Update(int id,Book newBook)
        {
            var book = database.Books.Include(b => b.Author).FirstOrDefault( b => b.Id == id );

            if (book == null)
                return NotFound();



            book.Price = newBook.Price;
            book.AuthorId = newBook.AuthorId;
          
           database.SaveChanges();
           
           return Ok(book);
            
        }


        //DELETE api/books/{id}
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var book = database.Books.FirstOrDefault(b => b.Id == id);
            if (book == null)
                return NotFound();

            database.Books.Remove(book);
            database.SaveChanges();

            return Ok(new { message = "Book Removed"});
        }

    }
}
