﻿using BooksApp.Helpers;
using BooksApp.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace BooksApp.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly IConfiguration configuration;
        private readonly DatabaseContext database;

        public UsersController(IConfiguration configuration, DatabaseContext database)
        {
            this.configuration = configuration;
            this.database = database;
        }

        [HttpPost]
        public IActionResult SignUp(User user)
        {
            var dbUser = database.Users.FirstOrDefault(u=>u.Username == user.Username);

            if (dbUser != null)
                return Conflict(new { Reason = "User already exists!!!" });

            if (user.Username.Equals("") || user.Password.Equals(""))
                return NotFound(new { message = "Username or Password is can not be Empty" });

            database.Users.Add(user);
            database.SaveChanges();

            return Ok(new {message="User Register"});
        }

        [HttpPost]
        public IActionResult Login(User user)
        {
            var dbUser = database.Users.FirstOrDefault(u => u.Username == user.Username && u.Password == user.Password);
            if (dbUser == null)
                return NotFound(new { message = "Bad Credentials" });

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration["Jwt:Key"]));
            var descriptor = new SecurityTokenDescriptor() 
            { 
                
                Subject = new ClaimsIdentity(new Claim[]
                {
                    new Claim(ClaimTypes.Name, dbUser.Id.ToString()),
                    new Claim(ClaimTypes.Role,"User")
                }),
                SigningCredentials = new SigningCredentials(key,SecurityAlgorithms.HmacSha256Signature)
            

            };

            var handler = new JwtSecurityTokenHandler();
            var token = handler.CreateToken(descriptor);
            var tokenString = handler.WriteToken(token);


            return Ok(new { Token = tokenString});


           
        }
    }
}
