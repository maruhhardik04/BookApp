﻿
using BooksApp.Helpers;
using BooksApp.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;




namespace BooksApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class AuthorsController : ControllerBase
    {
        private readonly DatabaseContext database;

        public AuthorsController(DatabaseContext database)
        {
            this.database = database;
        }

        //GET /api/authors

        [HttpGet]
        public IActionResult GetAll()
        {
            var authors = database.Authors.ToList();

            return Ok(authors) ;
        }

        //GET /api/books/{id:int}
        
        [HttpGet("{id:int}")]
        public IActionResult GetById(int id)
        {
           var auhtor= database.Authors.FirstOrDefault(a => a.Id == id);
          // var book = database.Books.Find(id);
            if (auhtor == null)
                return NotFound();
   
            return Ok(auhtor);
        }


     


        //POST api/books
        [HttpPost]
        public  IActionResult Add(Author author)
        {
            database.Authors.Add(author);
            database.SaveChanges();

            return Ok(author);
        }



         //PUT api/books/{id}
        [HttpPut("{id}")]
        public IActionResult Update(int id,Author newAuthor)
        {
            var author = database.Authors.FirstOrDefault( a => a.Id == id );
            if (author == null)
                return NotFound();

           author.Name= newAuthor.Name;
           
          
           database.SaveChanges();
           
           return Ok(author);
            
        }


        //DELETE api/books/{id}
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var author = database.Authors.FirstOrDefault(a => a.Id == id);
            if (author == null)
                return NotFound();

            database.Authors.Remove(author);
            database.SaveChanges();

            return Ok(new { message = "Author Removed"});
        }

    }
}
