﻿using Microsoft.EntityFrameworkCore;

using BooksApp.Models;

namespace BooksApp.Helpers
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext()
        {

        }

        public DatabaseContext(DbContextOptions options) : base(options)
        {

        }

        public  DbSet<User> Users { get; set; }
        public DbSet<Author> Authors { get; set; }   
        public DbSet<Book> Books { get; set; }

    }
}
